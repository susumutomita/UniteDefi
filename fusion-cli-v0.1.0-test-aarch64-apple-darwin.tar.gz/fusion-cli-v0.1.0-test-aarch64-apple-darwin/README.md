<div align="center">
  <img src="logo.svg" alt="UniteSwap Logo" width="200" height="200">

  # UniteSwap

  **First EVM ↔️ NEAR Atomic Swap Bridge**
</div>

<div align="center">

[![CI](https://github.com/susumutomita/UniteDefi/actions/workflows/ci.yml/badge.svg?branch=main)](https://github.com/susumutomita/UniteDefi/actions/workflows/ci.yml)
![GitHub last commit (by committer)](https://img.shields.io/github/last-commit/susumutomita/UniteDefi)
![GitHub top language](https://img.shields.io/github/languages/top/susumutomita/UniteDefi)
![GitHub pull requests](https://img.shields.io/github/issues-pr/susumutomita/UniteDefi)
![GitHub code size in bytes](https://img.shields.io/github/languages/code-size/susumutomita/UniteDefi)
![GitHub repo size](https://img.shields.io/github/repo-size/susumutomita/UniteDefi)

</div>

A Rust CLI for trustless atomic swaps between Ethereum (Base Sepolia) and NEAR Protocol using 1inch Limit Order Protocol and HTLC technology.

## 🏆 ETHGlobal Unite - Extend Fusion+ to NEAR

This project extends 1inch Fusion+ to enable trustless atomic swaps between Ethereum and NEAR Protocol, preserving hashlock and timelock functionality.

## 🎯 Project Overview

**UniteSwap** provides a Rust-based CLI tool (`fusion-cli`) that implements Hash Time Lock Contracts (HTLC) for secure atomic swaps between EVM and NEAR chains. Our implementation integrates with the official 1inch Limit Order Protocol on Ethereum and custom HTLC contracts on NEAR.

### Key Features
- ✅ **Official 1inch Integration** - Uses 1inch Limit Order Protocol on Base Sepolia
- ✅ **Bidirectional swaps** - ETH ↔ NEAR atomic swaps
- ✅ **HTLC Implementation** - Secure hashlock and timelock functionality
- ✅ **Integrated Swap Command** - Simplified cross-chain swaps
- ✅ **Automated Monitoring** - Real-time event tracking on both chains
- ✅ **Secret Management** - Secure generation and handling of HTLC secrets

## 🛠️ Architecture

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  Base Sepolia   │     │   Fusion+ Core  │     │  NEAR Protocol  │
│     (EVM)       │◄────┤   Rust CLI      ├────►│   (Non-EVM)     │
│                 │     │                 │     │                 │
│ - 1inch LOP     │     │ - HTLC Logic    │     │ - HTLC Contract │
│ - Escrow        │     │ - Secret Mgmt   │     │ - htlc-v2.      │
│ - ERC20 Tokens  │     │ - Monitoring    │     │   testnet       │
└─────────────────┘     └─────────────────┘     └─────────────────┘
```

## 🎯 NEW: Integrated Swap Command with Real Blockchain Transactions

The integrated swap command simplifies cross-chain token swaps by automating the entire process with **real blockchain transactions**:

### Why Use the Integrated Swap Command?

**Before (Manual Process):**
1. Generate secret manually
2. Create HTLC contract
3. Create limit order with HTLC parameters
4. Monitor order execution
5. Claim funds from HTLC
6. Handle errors and timeouts manually

**Now (Integrated Swap):**
```bash
fusion-cli swap --from-chain ethereum --to-chain near --amount 1.0 ...
```

### Features:
- **One Command**: Execute complete cross-chain swaps with a single command
- **Real Blockchain Transactions**: All operations create verifiable on-chain transactions
- **Automated Secret Management**: Secure generation and handling of HTLC secrets
- **Real-time Monitoring**: Track swap progress and automatic claim execution
- **Error Recovery**: Built-in retry logic and timeout handling
- **Batch Support**: Execute multiple swaps from configuration files
- **Price Oracle Integration**: Automatic price calculation with slippage protection

### Example Transaction Output:
```
Creating Ethereum order...
Transaction submitted successfully!
Transaction hash: 0x7f2542bcbba474cd2f32360968be9c59b98dae67873a4a60a1733af355b781cf
Block number: 29102175
Gas used: 150000
View on explorer: https://sepolia.basescan.org/tx/0x7f2542bcbba474cd2f32360968be9c59b98dae67873a4a60a1733af355b781cf
```

## 🚀 Quick Start

### Prerequisites
- Rust 1.75+
- Node.js 18+ (for Ethereum interaction)
- Chain-specific CLIs (near-cli for NEAR integration)

### Installation
```bash
# Clone the repository
git clone https://github.com/susumutomita/UniteDefi.git
cd UniteDefi

# Build the CLI
cargo build -p fusion-cli --release

# Install the CLI globally (optional)
cargo install --path fusion-cli

# Or run directly from target directory
./target/release/fusion-cli --help
```

### Quick Example: Create and Claim HTLC
```bash
# 1. Create an HTLC (this generates a secret)
./target/release/fusion-cli create-htlc \
  --sender 0x7aD8317e9aB4837AEF734e23d1C62F4938a6D950 \
  --recipient 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913 \
  --amount 1000000000000000000

# 2. Note the secret and htlc_id from the output, then claim it
./target/release/fusion-cli claim \
  --htlc-id <htlc_id_from_output> \
  --secret <secret_from_output>
```

### Basic Usage

#### HTLC Operations
```bash
# Create a new HTLC
fusion-cli create-htlc \
  --sender 0x7aD8317e9aB4837AEF734e23d1C62F4938a6D950 \
  --recipient 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913 \
  --amount 1000 \
  --timeout 3600

# Example output:
# {
#   "htlc_id": "htlc_6c2c0d83",
#   "secret": "27eddfe62b6a8a7787b2bfe30694d334500ed8f134b5f3f9b7a047605c7a9518",
#   "secret_hash": "6c2c0d83023b6dba52903a91952ab0cde4a0ce554d80a9f07ec815e54438a263",
#   "sender": "0x7aD8317e9aB4837AEF734e23d1C62F4938a6D950",
#   "recipient": "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913",
#   "amount": 1000,
#   "timeout_seconds": 3600,
#   "status": "Pending"
# }

# Claim an HTLC with secret (use the secret from create-htlc output)
fusion-cli claim \
  --htlc-id htlc_6c2c0d83 \
  --secret 27eddfe62b6a8a7787b2bfe30694d334500ed8f134b5f3f9b7a047605c7a9518

# Refund an HTLC after timeout
fusion-cli refund --htlc-id htlc_6c2c0d83
```

#### Limit Order Operations
```bash
# Create a limit order (Ethereum/Base)
fusion-cli order create \
  --maker-asset 0x4200000000000000000000000000000000000006 \
  --taker-asset 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913 \
  --maker 0x7aD8317e9aB4837AEF734e23d1C62F4938a6D950 \
  --making-amount 1000000000000000000 \
  --taking-amount 3000000000 \
  --htlc-secret-hash 0x[secret-hash-from-create-htlc] \
  --htlc-timeout 3600 \
  --chain-id 84532 \
  --verifying-contract 0x171C87724E720F2806fc29a010a62897B30fdb62

# Create a NEAR to Ethereum order
fusion-cli order create-near \
  --near-account alice.near \
  --ethereum-address 0x7aD8317e9aB4837AEF734e23d1C62F4938a6D950 \
  --near-amount 10.0 \
  --generate-secret

# Check order status
fusion-cli order status --order-id <order-id>

# Cancel an active order
fusion-cli order cancel --order-id <order-id>

# View orderbook for a specific chain
fusion-cli orderbook --chain ethereum
```

#### Integrated Swap Command 🎯 NEW!
```bash
# Single command for seamless cross-chain swaps
# Ethereum → NEAR swap
fusion-cli swap \
  --from-chain ethereum \
  --to-chain near \
  --from-token 0x4200000000000000000000000000000000000006 \
  --to-token NEAR \
  --amount 1.0 \
  --from-address 0x7aD8317e9aB4837AEF734e23d1C62F4938a6D950 \
  --to-address alice.near \
  --slippage 1.0

# NEAR → Ethereum swap
fusion-cli swap \
  --from-chain near \
  --to-chain ethereum \
  --from-token NEAR \
  --to-token 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913 \
  --amount 10.0 \
  --from-address alice.near \
  --to-address 0x7aD8317e9aB4837AEF734e23d1C62F4938a6D950

# Advanced swap with custom options
fusion-cli swap \
  --from-chain ethereum \
  --to-chain near \
  --from-token WETH \
  --to-token NEAR \
  --amount 0.5 \
  --from-address 0x7aD8317e9aB4837AEF734e23d1C62F4938a6D950 \
  --to-address alice.near \
  --slippage 0.5 \
  --timeout 7200 \
  --auto-claim \
  --monitor-interval 30

# Batch swaps from configuration file
fusion-cli swap batch \
  --config swaps.json \
  --dry-run

# Example swaps.json:
# [
#   {
#     "from_chain": "ethereum",
#     "to_chain": "near",
#     "from_token": "WETH",
#     "to_token": "NEAR",
#     "amount": 0.5,
#     "from_address": "0x7aD8317e9aB4837AEF734e23d1C62F4938a6D950",
#     "to_address": "alice.near"
#   },
#   {
#     "from_chain": "near",
#     "to_chain": "ethereum",
#     "from_token": "NEAR",
#     "to_token": "USDC",
#     "amount": 10.0,
#     "from_address": "bob.near",
#     "to_address": "0x7aD8317e9aB4837AEF734e23d1C62F4938a6D950"
#   }
# ]
```

#### Cross-Chain Operations
```bash
# Relay an order from EVM to another chain (currently only NEAR supported)
fusion-cli relay-order \
  --order-hash 0x[actual-order-hash-from-previous-command] \
  --to-chain near \
  --htlc-secret 0x[actual-secret-from-create-htlc] \
  --near-account alice.near
```

### Command Reference

#### Available Commands
```bash
# Display help information
fusion-cli --help
fusion-cli <command> --help

# HTLC commands
fusion-cli create-htlc    # Create a new HTLC
fusion-cli claim          # Claim an HTLC with secret
fusion-cli refund         # Refund an HTLC after timeout

# Order commands
fusion-cli order create       # Create a new limit order (EVM)
fusion-cli order create-near  # Create a NEAR to Ethereum order
fusion-cli order status       # Check order status
fusion-cli order cancel       # Cancel an order

# Cross-chain operations
fusion-cli relay-order    # Relay an order from EVM to another chain
fusion-cli orderbook      # Display orderbook for a specific chain

# Integrated swap command (NEW!)
fusion-cli swap          # Single-command cross-chain swap
fusion-cli swap batch    # Execute multiple swaps from config file
```

## 📋 Hackathon Requirements Checklist

### Core Requirements ✅
- [x] **Hashlock and Timelock Preservation**: All non-EVM implementations maintain HTLC security properties
- [x] **Bidirectional Swaps**: Support for both EVM→non-EVM and non-EVM→EVM swaps
- [x] **On-chain Execution Demo**: Testnet demonstrations available for all supported chains
- [x] **1inch Escrow Integration**: Uses official 1inch escrow factory and contracts

### Stretch Goals 🎯
- [x] **Partial Fill Support**: Multiple secrets for partial order filling
- [x] **Relayer Implementation**: Custom relayer for non-EVM chains
- [ ] **UI Implementation**: CLI-first approach, UI planned post-hackathon
- [ ] **Mainnet Deployment**: Testnet validated, mainnet deployment ready

## 🔧 Technical Implementation

### Core HTLC Trait
```rust
#[async_trait]
pub trait HTLCContract {
    async fn create_lock(
        &self,
        secret_hash: [u8; 32],
        recipient: String,
        amount: u128,
        timeout: u64,
    ) -> Result<String>;

    async fn claim_with_secret(
        &self,
        lock_id: String,
        secret: [u8; 32],
    ) -> Result<TransactionHash>;

    async fn refund_after_timeout(
        &self,
        lock_id: String,
    ) -> Result<TransactionHash>;
}
```

### Supported Chains

#### Base Sepolia (EVM)

- 1inch Limit Order Protocol: `0x171C87724E720F2806fc29a010a62897B30fdb62`
- Escrow Factory: `0x848285f35044e485BD5F0235c27924b1392144b3`
- Full ERC20 token support

#### NEAR Protocol

- Smart contract: `htlc-v2.testnet`
- Uses NEAR's native timing and storage
- Gas-efficient implementation
- Fully tested and operational

## 🧪 Testing

### Run Tests

```bash
# Unit tests (workspace only)
cargo test --workspace

# CLI integration tests
cargo test -p fusion-cli

# Core functionality tests
cargo test -p fusion-core

# NEAR contract tests (separate build)
cd contracts/near-htlc && cargo test
```

### Testnet Deployments

- **Base Sepolia**: 1inch Limit Order Protocol integration (default)
- **NEAR Testnet**: Custom HTLC contracts at `htlc-v2.testnet`

## 🏗️ Technical Implementation

### Implemented Features
- **Cross-chain HTLC**: Secure atomic swaps between EVM and NEAR
- **1inch Integration**: Compatible with official Limit Order Protocol
- **Transaction Signing**: EIP-712 compliant order signing
- **Real Transactions**: Actual blockchain transaction submission (not mocked)
- **CLI Interface**: Comprehensive command-line tools

## 🏗️ Project Structure

```text
UniteDefi/
├── fusion-cli/         # CLI implementation
│   ├── src/           # CLI source code
│   └── tests/         # CLI integration tests
├── fusion-core/       # Core HTLC and cross-chain logic
│   ├── src/           # Core functionality
│   ├── tests/         # Unit and integration tests
│   └── examples/      # Usage examples
├── contracts/         # Smart contracts
│   └── near-htlc/     # NEAR HTLC implementation
│       ├── src/       # Contract source
│       └── tests/     # Contract tests
├── docs/              # Documentation
└── Cargo.toml         # Workspace configuration
```

## 🔐 Security Considerations

1. **Secret Generation**: Uses cryptographically secure random number generation
2. **Timeout Handling**: Automatic refunds after timeout expiration
3. **Atomic Guarantees**: Both chains succeed or both fail - no funds at risk
4. **Signature Verification**: All operations require proper authorization

## 📍 Deployed Contracts

### Base Sepolia (Chain ID: 84532)

- **Limit Order Protocol**: [`0x171C87724E720F2806fc29a010a62897B30fdb62`](https://sepolia.basescan.org/address/0x171C87724E720F2806fc29a010a62897B30fdb62)
- **Escrow Factory**: [`0x848285f35044e485BD5F0235c27924b1392144b3`](https://sepolia.basescan.org/address/0x848285f35044e485BD5F0235c27924b1392144b3)

### NEAR Testnet

- **HTLC Contract**:
  - `htlc-v2.testnet` (fully operational)
  - Explorer: [https://testnet.nearblocks.io/address/htlc-v2.testnet](https://testnet.nearblocks.io/address/htlc-v2.testnet)
  - Owner: `uniteswap.testnet`
  - Status: ✅ Live and tested

## 🎬 Demo

### Pre-built Binary Demo (No Setup Required)

Download and run the CLI without building from source:

1. **Download the latest release** from [GitHub Releases](https://github.com/susumutomita/UniteDefi/releases)
2. Extract and run:

   ```bash
   tar -xzf fusion-cli-*.tar.gz
   cd fusion-cli-*
   ./run.sh --help
   ```

For detailed instructions, see [RELEASES.md](./RELEASES.md).

### Quick Demo

Test the NEAR HTLC functionality:

```bash
./demo/quick-demo.sh
```

### Full Cross-Chain Demo

Simulate a complete atomic swap between Ethereum and NEAR:

```bash
./demo/cross-chain-swap-demo.sh
```

### Demo Guide

For detailed instructions and troubleshooting:

```bash
cat demo/DEMO_GUIDE.md
```

## 🤝 Team

- **Lead Developer**: [Susumu Tomita](https://susumutomita.netlify.app/)

## 📜 License

MIT License - see LICENSE file for details
